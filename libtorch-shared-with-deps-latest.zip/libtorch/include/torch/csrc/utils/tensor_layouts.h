#pragma once

namespace torch { namespace utils {

void initializeLayouts();

}} // namespace torch::utils
